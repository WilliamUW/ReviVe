// custom.d.ts
interface Window {
    webkitSpeechRecognition: any;
  }
  