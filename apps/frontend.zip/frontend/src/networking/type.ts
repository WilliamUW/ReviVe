export interface ReceiptData {
    image: string;
    address: string;
    captcha: string;
    deviceID: string;
}
